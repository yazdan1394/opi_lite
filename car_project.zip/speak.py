import speech_recognition as sr
from arabic_reshaper import reshape as re
#from bidi.algorithm import get_display as gd
import vlc
import time
r = sr.Recognizer()
with sr.Microphone() as source:
    # read the audio data from the default microphone
    print("please speak.")
    audio_data = r.record(source, duration=5)
    print("Recognizing...")
    # convert speech to text
    text = r.recognize_google(audio_data, language="Fa")
    print((text))
    #fatext=gd(re(text))
    #print(fatext)
    #print(text.find("یزدان"))
    if text.find("یزدان")!=-1 :
        print("playing...")
        media=vlc.MediaPlayer("you.wma")
        media.play()
        time.sleep(5)
        media.stop()
    
    if text.find("یسنا")!=-1 :
        print("playing...")
        media=vlc.MediaPlayer("hello.mp3")
        media.play()
        time.sleep(5)
        media.stop()
        