import requests
try:
    r = requests.get("http://192.168.0.102:80/temp/")
    print(f"Status Code: {r.status_code}")
    print(r._content)
    print(r.text)
    
except:
    print("Failed to send message")
   # requests.