from skimage.metrics import structural_similarity as ssim
from skimage.io import imread

# Load images in grayscale
img1 = imread('1.jpg', as_gray=True)  # `as_gray=True` ensures grayscale loading
img2 = imread('2.jpg', as_gray=True)

# Compute SSIM (data_range inferred for uint8 images)
score, diff = ssim(img1, img2, full=True, data_range=255)
print(f"SSIM Score: {score}")