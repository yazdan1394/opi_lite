import vlc
import time
media=vlc.MediaPlayer("you.wma")
media.play()
time.sleep(5)
media.stop()