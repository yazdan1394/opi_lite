from playsound import playsound
playsound('audio.mp3')
