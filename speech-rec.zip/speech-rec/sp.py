import speech_recognition as sr
from arabic_reshaper import reshape as re
from bidi.algorithm import get_display as gd
from persianttsfarsi import PersianTTS
import vlc
import time
tts = PersianTTS()
#import subprocess
#import time,os
#player_path=r"C:\\Program Files\\KMPlayer 64X\\KMPlayer64.exe"
#mp3_path=r"C:\\Users\\yazdan\Desktop\speech-rec\\python.mp3"
#print(gd(re("سلام خوبی")))
#p=subprocess.run([player_path, mp3_path])
r = sr.Recognizer()
with sr.Microphone() as source:
    # read the audio data from the default microphone
    print("please speak.")
    audio_data = r.record(source, duration=5)
    print("Recognizing...")
    # convert speech to text
    text = r.recognize_google(audio_data, language="Fa")
    fatext=gd(re(text))
    print(fatext)
    print(fatext.find("سلام"))
    #if(fatext.find("سلام")==True):
    #    print(fatext[3])
    
#    time.sleep(2)
#    tts.synthesize(text, "output.mp3")
#    print("saving...")
#    time.sleep(1)
    #ss=normalizer.normalize(text)
    #if(fatext=="سلام"):   
   
   
    #print("playing...")
    #media=vlc.MediaPlayer("you.wma")
    #media.play()
    #time.sleep(5)
    #media.stop()