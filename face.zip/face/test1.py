# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'test1.ui'
#
# Created by: PyQt5 UI code generator 5.13.0
#
# WARNING! All changes made in this file will be lost!


from PyQt5 import QtCore, QtGui, QtWidgets
import cv2
import numpy as np

class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(800, 600)
        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")
        self.start_detect = QtWidgets.QPushButton(self.centralwidget)
        self.start_detect.setGeometry(QtCore.QRect(30, 310, 141, 51))
        font = QtGui.QFont()
        font.setPointSize(12)
        self.start_detect.setFont(font)
        self.start_detect.setObjectName("start_detect")
        self.stop_detect = QtWidgets.QPushButton(self.centralwidget)
        self.stop_detect.setGeometry(QtCore.QRect(190, 310, 141, 51))
        font = QtGui.QFont()
        font.setPointSize(12)
        self.stop_detect.setFont(font)
        self.stop_detect.setObjectName("stop_detect")
        MainWindow.setCentralWidget(self.centralwidget)
        self.menubar = QtWidgets.QMenuBar(MainWindow)
        self.menubar.setGeometry(QtCore.QRect(0, 0, 800, 21))
        self.menubar.setObjectName("menubar")
        MainWindow.setMenuBar(self.menubar)
        self.statusbar = QtWidgets.QStatusBar(MainWindow)
        self.statusbar.setObjectName("statusbar")
        MainWindow.setStatusBar(self.statusbar)

        self.retranslateUi(MainWindow)
        self.start_detect.clicked.connect(self.face_detect)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)
    
    def face_detect(self, MainWindow) :
        recognizer = cv2.face.LBPHFaceRecognizer_create()
        recognizer.read('C:\\vscode-project\\face\\trainningData.yml')
        cascadePath = "cascade.xml"
        faceCascade = cv2.CascadeClassifier(cascadePath);
        cam = cv2.VideoCapture(0)
        flag=0
        while True:
            ret, im =cam.read()
            gray=cv2.cvtColor(im,cv2.COLOR_BGR2GRAY)
            faces=faceCascade.detectMultiScale(gray, 1.2,5)
            for(x,y,w,h) in faces:
                cv2.rectangle(im,(x,y),(x+w,y+h),(225,0,0),2)
                Id, conf = recognizer.predict(gray[y:y+h,x:x+w])
                if(conf>50):
                    if(Id==1):
                        Id="yousef"
                        cv2.putText(im,"yousef",(x,y+w),cv2.FONT_HERSHEY_SIMPLEX,0.6,(0,255,255),2)
                        flag=1
                    if(Id==2):
                        Id="zeinab"
                        cv2.putText(im,"monireh",(x,y+w),cv2.FONT_HERSHEY_SIMPLEX,0.6,(0,255,255),2)

                    if(Id==3):
                        Id="yazdan"
                        cv2.putText(im,"masoomeh",(x,y+w),cv2.FONT_HERSHEY_SIMPLEX,0.6,(0,255,255),2)

                    if(Id==4):
                        Id="yasna"
                        cv2.putText(im,"yasna",(x,y+w),cv2.FONT_HERSHEY_SIMPLEX,0.6,(0,255,255),2)      
            cv2.imshow('im',im) 
            if (cv2.waitKey(1)==ord('q')):
                break
        cam.release()
        cv2.destroyAllWindows()

    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "MainWindow"))
        self.start_detect.setText(_translate("MainWindow", "START DETECT"))
        self.stop_detect.setText(_translate("MainWindow", "STOP DETECT"))

if __name__=="__main__" :
    import sys
    app=QtWidgets.QApplication(sys.argv)
    MainWindow=QtWidgets.QMainWindow()
    ui=Ui_MainWindow()
    ui.setupUi(MainWindow)
    MainWindow.show()
    sys.exit(app.exec_())
    