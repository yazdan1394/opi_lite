import cv2
import numpy as np
recognizer = cv2.face.LBPHFaceRecognizer_create()
recognizer.read('\\face\\trainningData.yml')
cascadePath = "haarcascade_frontalface_default.xml"
faceCascade = cv2.CascadeClassifier(cascadePath);
cam = cv2.VideoCapture(0)
#font = cv2.cv.InitFont(cv2.cv.CV_FONT_HERSHEY_SIMPLEX, 1, 1, 0, 1, 1)
while True:
    ret, im =cam.read()
    gray=cv2.cvtColor(im,cv2.COLOR_BGR2GRAY)
    faces=faceCascade.detectMultiScale(gray, 1.2,5)
    for(x,y,w,h) in faces:
        cv2.rectangle(im,(x,y),(x+w,y+h),(225,0,0),2)
        Id, conf = recognizer.predict(gray[y:y+h,x:x+w])
        print(conf)
        if(conf<50):
            if(Id==1):
                Id="yousef"
                cv2.putText(im,"yousef",(x,y+w),cv2.FONT_HERSHEY_SIMPLEX,0.6,(0,255,255),2)
               
            if(Id==2):
                Id="monireh"
                cv2.putText(im,"monireh",(x,y+w),cv2.FONT_HERSHEY_SIMPLEX,0.6,(0,255,255),2)

            if(Id==3):
                Id="masoomeh"
                cv2.putText(im,"masoomeh",(x,y+w),cv2.FONT_HERSHEY_SIMPLEX,0.6,(0,255,255),2)
                
        #else:
         #   Id="Unknown"
        #print(Id)
       # cv2.putText(im,"yousef",)
       # cv2.putText(im,"yousef",(x,y+w),cv2.FONT_HERSHEY_SIMPLEX,0.6,(0,255,255),2)
      #  cv2.rectangle(im,(x,y),(x+w+5,y+h+5),(225,255,0),2)
       # cv2.cv.PutText(cv2.cv.fromarray(im),str(Id), (x,y+h),4, 255)
    cv2.imshow('im',im) 
    if (cv2.waitKey(1)==ord('q')):
        break
cam.release()
cv2.destroyAllWindows()