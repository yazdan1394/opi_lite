import cv2
import numpy as np

recognizer = cv2.face.LBPHFaceRecognizer_create()
recognizer.read('trainningData.yml')
cascadePath = "haarcascade_frontalface_default.xml"
faceCascade = cv2.CascadeClassifier(cascadePath);
cam = cv2.VideoCapture(0)
while True:
    ret, im =cam.read()
    gray=cv2.cvtColor(im,cv2.COLOR_BGR2GRAY)
    faces=faceCascade.detectMultiScale(gray, 1.2,5)
    for(x,y,w,h) in faces:
        cv2.rectangle(im,(x,y),(x+w,y+h),(225,0,0),2)
        Id, conf = recognizer.predict(gray[y:y+h,x:x+w])
        if(conf<60):
            if(Id==1):
                Id="yousef"
                cv2.putText(im,"yousef",(x,y+w),cv2.FONT_HERSHEY_SIMPLEX,0.6,(0,255,255),2)
               
            if(Id==2):
                Id="monireh"
                cv2.putText(im,"monireh",(x,y+w),cv2.FONT_HERSHEY_SIMPLEX,0.6,(0,255,255),2)

            if(Id==3):
                Id="masoomeh"
                cv2.putText(im,"masoomeh",(x,y+w),cv2.FONT_HERSHEY_SIMPLEX,0.6,(0,255,255),2)

            if(Id==4):
                Id="yasna"
                cv2.putText(im,"yasna",(x,y+w),cv2.FONT_HERSHEY_SIMPLEX,0.6,(0,255,255),2)
                
        
    cv2.imshow('im',im) 
    if (cv2.waitKey(1)==ord('q')):
        break
cam.release()
cv2.destroyAllWindows()